<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a28575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\141\164\x65\162\x69\141\154\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\141\164\x65\x72\x69\x61\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\141\x74\x65\x72\151\141\154\x20\146\157\x72\x20\160\x72\x6f\x64\x75\x63\164\163", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\115\x65\144\151\165\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }
