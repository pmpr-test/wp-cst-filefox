<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99a2347d7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\141\x74\145\162\x69\141\154\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\141\164\145\162\151\141\154", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\141\164\x65\162\x69\141\x6c\40\x66\x6f\x72\x20\x70\162\x6f\144\165\x63\x74\163", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\x4d\145\x64\151\165\x6d", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka())->mkksewyosgeumwsa($uuyucgkyusckoaeq->gosycecgwuesyysq(Constants::qgqyauaqwqmqseim)->gswweykyogmsyawy(__("\x49\x63\x6f\x6e", PR__CST__FILEFOX))); } }
