<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0003ea178             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x61\x74\145\x72\151\x61\154\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\141\x74\x65\x72\151\141\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\141\x74\x65\162\151\141\x6c\x20\x66\x6f\162\x20\x70\x72\157\144\165\x63\x74\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\115\145\144\x69\x75\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }
