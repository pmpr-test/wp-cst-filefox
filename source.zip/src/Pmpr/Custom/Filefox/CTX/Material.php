<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46aadb997             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x61\x74\145\162\151\141\154\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x61\x74\x65\x72\x69\x61\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x61\x74\x65\x72\x69\141\x6c\x20\x66\x6f\x72\40\160\162\x6f\x64\165\143\164\163", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\x4d\x65\144\151\x75\x6d", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }
