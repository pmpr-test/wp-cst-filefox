<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3ff82412c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\x61\164\x65\x72\x69\x61\x6c\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\141\164\145\162\x69\141\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\141\164\145\162\x69\141\x6c\40\146\x6f\162\x20\160\162\x6f\144\x75\x63\164\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\165\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka())->mkksewyosgeumwsa($uuyucgkyusckoaeq->gosycecgwuesyysq(Constants::qgqyauaqwqmqseim)->gswweykyogmsyawy(__("\x49\143\157\x6e", PR__CST__FILEFOX))); } }
