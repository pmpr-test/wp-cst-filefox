<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebea329a6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x61\164\x65\162\x69\x61\x6c\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x61\x74\145\x72\151\x61\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x61\164\145\x72\151\x61\154\40\x66\157\x72\x20\160\162\157\144\165\x63\x74\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\115\145\x64\151\165\x6d", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }
