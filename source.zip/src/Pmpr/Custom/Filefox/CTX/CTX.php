<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9eafc18a58             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Container; class CTX extends Container { public function mameiwsayuyquoeq() { Medium::symcgieuakksimmu(); Material::symcgieuakksimmu(); Category::symcgieuakksimmu(); Application::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('term_link', [$this, 'kucsyooaaqiseewe'], 999, 2); $this->aqaqisyssqeomwom('taxonomy_single_value_modify_items', [$this, 'scoayamuyqgkcamg']); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } public function kucsyooaaqiseewe($iwywmkygwewiamwm, $iwewcwusemqaiggk) { $kesssewsiegssiya = $this->caokeucsksukesyo()->kckogqkiycqeumoa()->yyoeeseewqmmyaee($iwewcwusemqaiggk, Constants::ckmqoekmugkggeym); if (!$this->caokeucsksukesyo()->yyoeeseewqmmyaee()->cekoogweeooasayu($kesssewsiegssiya)) { $iwywmkygwewiamwm = ''; } return $iwywmkygwewiamwm; } }
