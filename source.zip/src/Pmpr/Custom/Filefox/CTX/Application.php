<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795e80fc4619             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\160\x6c\151\143\141\164\151\157\156\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\x70\x6c\151\x63\141\164\x69\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\160\x6c\x69\x63\x61\x74\151\x6f\156\40\x66\x6f\162\40\160\x72\x6f\x64\165\x63\164\163", PR__CST__FILEFOX)); } }
