<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a28575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\x70\x6c\151\143\x61\x74\x69\157\x6e\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\160\154\151\143\141\x74\x69\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\160\160\154\x69\143\141\x74\151\x6f\156\x20\x66\157\162\40\160\162\157\144\165\x63\164\x73", PR__CST__FILEFOX)); } }
