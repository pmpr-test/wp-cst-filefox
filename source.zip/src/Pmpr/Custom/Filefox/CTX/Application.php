<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b688e00             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\160\x6c\151\143\141\x74\x69\x6f\x6e\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\160\160\154\151\143\141\164\x69\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\x70\160\154\151\x63\141\x74\151\x6f\x6e\40\x66\x6f\x72\x20\160\162\x6f\x64\165\x63\x74\163", PR__CST__FILEFOX)); } }
