<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffd43d060             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\160\154\151\x63\141\x74\x69\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\160\x6c\151\143\141\164\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\160\x6c\151\x63\x61\164\151\x6f\156\40\x66\157\162\40\x70\x72\x6f\144\165\x63\164\163", PR__CST__FILEFOX)); } }
