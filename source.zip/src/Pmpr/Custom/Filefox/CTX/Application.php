<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff670872f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\160\154\151\x63\x61\164\x69\x6f\156\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\160\x70\154\151\x63\141\x74\151\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\x70\x6c\x69\x63\141\164\151\157\x6e\x20\x66\157\162\x20\x70\162\x6f\x64\165\x63\x74\x73", PR__CST__FILEFOX)); } }
