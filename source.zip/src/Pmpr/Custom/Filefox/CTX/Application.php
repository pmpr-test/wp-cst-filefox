<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793d96464dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\160\x6c\151\143\141\164\x69\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\x70\x6c\151\143\x61\x74\151\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\160\x6c\x69\x63\x61\164\x69\x6f\x6e\40\x66\157\162\40\x70\162\157\x64\165\143\x74\163", PR__CST__FILEFOX)); } }
