<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06163927             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\x70\160\154\151\x63\x61\164\151\x6f\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\x70\x6c\151\x63\141\164\x69\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\160\160\154\x69\143\x61\x74\151\157\156\x20\x66\157\162\40\x70\x72\157\x64\x75\143\x74\163", PR__CST__FILEFOX)); } }
