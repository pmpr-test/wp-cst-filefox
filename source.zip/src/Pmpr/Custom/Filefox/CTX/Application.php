<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051750f1acb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\160\154\x69\143\x61\164\x69\157\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\160\x6c\x69\x63\141\164\151\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\x70\154\151\143\x61\164\151\157\156\40\146\157\162\40\160\x72\x6f\144\x75\x63\x74\163", PR__CST__FILEFOX)); } }
