<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcdd6092ae             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\x70\x6c\151\x63\141\164\x69\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\x70\154\x69\143\x61\164\151\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\160\154\x69\143\x61\164\151\x6f\156\40\x66\157\x72\40\160\162\x6f\144\165\143\x74\163", PR__CST__FILEFOX)); } }
