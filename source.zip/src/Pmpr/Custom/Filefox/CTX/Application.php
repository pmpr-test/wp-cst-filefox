<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99a2347d7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\x70\160\154\151\143\x61\x74\x69\157\156\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\x70\154\x69\143\x61\x74\151\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\160\x6c\x69\x63\x61\x74\x69\x6f\x6e\x20\x66\x6f\162\x20\160\162\x6f\144\x75\x63\164\163", PR__CST__FILEFOX)); } }
