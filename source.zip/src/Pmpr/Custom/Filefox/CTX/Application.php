<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46aadb997             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\160\x6c\x69\x63\x61\x74\x69\x6f\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\160\160\x6c\x69\143\141\164\x69\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\x70\x70\x6c\151\143\141\164\151\157\156\40\x66\x6f\162\40\160\162\157\144\165\x63\164\163", PR__CST__FILEFOX)); } }
