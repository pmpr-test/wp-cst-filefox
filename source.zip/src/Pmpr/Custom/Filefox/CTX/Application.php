<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe567a38             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\160\x6c\x69\x63\141\164\151\157\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\160\x6c\x69\143\x61\164\x69\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\x70\160\154\x69\x63\x61\164\x69\157\x6e\x20\146\157\x72\x20\x70\x72\x6f\x64\x75\x63\164\163", PR__CST__FILEFOX)); } }
