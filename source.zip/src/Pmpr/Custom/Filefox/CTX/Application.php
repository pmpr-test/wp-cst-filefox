<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d719a78e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\160\x6c\x69\x63\x61\x74\x69\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\160\154\x69\143\141\164\x69\x6f\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\x70\154\x69\x63\x61\x74\151\157\156\40\x66\x6f\162\40\x70\162\x6f\x64\x75\143\x74\x73", PR__CST__FILEFOX)); } }
