<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679151225ff18             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\x70\154\x69\143\x61\164\151\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\160\x6c\x69\143\x61\164\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\160\160\x6c\151\x63\141\x74\x69\157\x6e\x20\x66\157\162\40\160\x72\x6f\144\x75\x63\x74\163", PR__CST__FILEFOX)); } }
