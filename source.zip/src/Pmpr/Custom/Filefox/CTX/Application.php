<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977edcdf95d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\160\x6c\x69\x63\x61\x74\151\157\x6e\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\160\x70\154\151\143\x61\x74\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\160\x6c\x69\143\x61\x74\151\157\156\x20\146\157\162\x20\160\162\157\x64\x75\x63\164\x73", PR__CST__FILEFOX)); } }
