<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0003ea178             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\x70\x6c\151\143\x61\x74\151\x6f\156\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\160\160\x6c\x69\143\141\x74\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\x70\154\x69\x63\141\164\151\157\x6e\40\x66\x6f\x72\40\160\162\157\144\x75\143\164\163", PR__CST__FILEFOX)); } }
