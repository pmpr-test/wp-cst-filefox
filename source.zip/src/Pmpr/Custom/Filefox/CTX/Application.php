<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c1a363             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\x70\160\154\151\x63\x61\164\x69\157\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\x70\154\x69\x63\x61\164\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\x70\x6c\151\x63\x61\x74\x69\x6f\156\40\x66\157\162\40\160\162\x6f\144\x75\143\x74\163", PR__CST__FILEFOX)); } }
