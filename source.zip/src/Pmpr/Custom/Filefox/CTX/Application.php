<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb83d60f3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\160\x6c\151\x63\x61\x74\151\x6f\x6e\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\x70\x6c\151\143\141\164\151\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\160\154\151\143\141\x74\x69\x6f\x6e\x20\x66\157\x72\40\160\x72\157\144\165\143\164\x73", PR__CST__FILEFOX)); } }
