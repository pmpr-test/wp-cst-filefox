<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977edcdf95d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\x65\x64\x69\x75\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x65\144\151\165\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x65\x64\151\165\155\x20\146\157\162\40\160\x72\x6f\x64\165\143\164\163", PR__CST__FILEFOX)); } }
