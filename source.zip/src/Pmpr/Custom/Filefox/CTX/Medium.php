<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d410ebe55a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x65\x64\x69\x75\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\145\144\151\x75\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\145\x64\151\x75\155\x20\x66\x6f\x72\x20\160\x72\157\x64\x75\143\164\x73", PR__CST__FILEFOX)); } }
