<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3ff82412c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\x75\155\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\145\x64\151\x75\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x65\x64\151\165\x6d\40\146\157\x72\x20\x70\162\157\144\165\143\x74\x73", PR__CST__FILEFOX)); } }
