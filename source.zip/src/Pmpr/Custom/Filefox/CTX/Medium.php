<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c5a9508             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\x75\155\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x65\144\x69\x75\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\145\x64\x69\165\155\40\146\x6f\x72\40\160\162\157\144\165\x63\x74\x73", PR__CST__FILEFOX)); } }
