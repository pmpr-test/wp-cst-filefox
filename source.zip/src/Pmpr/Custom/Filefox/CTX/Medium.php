<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c1a363             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\145\x64\151\165\155\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x65\144\151\165\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\145\x64\151\x75\155\x20\146\x6f\x72\x20\160\162\x6f\x64\x75\x63\x74\163", PR__CST__FILEFOX)); } }
