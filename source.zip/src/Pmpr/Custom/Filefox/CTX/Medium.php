<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdd04cd2cc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\x64\151\165\155\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x65\144\151\x75\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x65\x64\x69\x75\x6d\40\146\157\x72\40\160\x72\157\144\x75\143\x74\x73", PR__CST__FILEFOX)); } }
