<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8ce889f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\145\144\151\165\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x65\144\151\x75\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\x65\x64\151\x75\x6d\x20\146\x6f\162\x20\160\162\x6f\144\165\x63\x74\163", PR__CST__FILEFOX)); } }
