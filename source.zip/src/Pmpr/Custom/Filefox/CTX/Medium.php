<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523954224             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x65\144\x69\x75\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x65\x64\151\165\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\145\144\151\165\x6d\40\x66\157\x72\x20\160\x72\x6f\144\x75\x63\x74\163", PR__CST__FILEFOX)); } }
