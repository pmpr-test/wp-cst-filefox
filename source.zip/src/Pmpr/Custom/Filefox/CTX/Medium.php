<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4759a2f6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\x65\x64\x69\165\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x65\x64\x69\165\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\x65\144\151\165\155\40\146\157\162\40\x70\x72\157\x64\165\x63\164\x73", PR__CST__FILEFOX)); } }
