<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46aadb997             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\165\x6d\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\145\x64\x69\165\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\145\144\x69\165\155\40\146\157\162\x20\x70\x72\157\x64\165\143\164\163", PR__CST__FILEFOX)); } }
