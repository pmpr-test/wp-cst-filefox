<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977cbabe45f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\x6c\145\x5f\x72\145\x71\x75\145\163\x74"; const suooagqkicoeawcy = "\146\x69\x6c\x65\137\160\x72\157\166\151\x64\145"; }
