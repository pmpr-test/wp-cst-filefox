<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06163927             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\x65\x5f\x72\145\x71\x75\145\x73\x74"; const suooagqkicoeawcy = "\146\x69\x6c\145\x5f\x70\162\x6f\166\x69\x64\x65"; }
