<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99a2347d7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\x65\137\162\x65\161\x75\x65\163\x74"; const suooagqkicoeawcy = "\x66\x69\x6c\x65\137\160\162\x6f\x76\151\x64\145"; }
