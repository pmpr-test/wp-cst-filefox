<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793d96464dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\154\145\137\x72\145\161\x75\145\x73\164"; const suooagqkicoeawcy = "\146\151\154\x65\x5f\160\162\157\x76\x69\144\145"; }
