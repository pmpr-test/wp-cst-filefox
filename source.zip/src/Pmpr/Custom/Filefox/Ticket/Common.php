<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977edcdf95d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\x6c\x65\x5f\x72\145\161\165\145\163\164"; const suooagqkicoeawcy = "\x66\x69\x6c\x65\x5f\160\162\157\x76\x69\x64\145"; }
