<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb2c6f1b5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\154\x65\137\x72\145\x71\x75\x65\163\x74"; const suooagqkicoeawcy = "\146\151\x6c\145\137\160\x72\x6f\x76\x69\144\145"; }
