<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c1a363             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\x65\137\162\x65\161\165\x65\163\164"; const suooagqkicoeawcy = "\x66\151\x6c\145\x5f\160\162\157\x76\x69\144\145"; }
