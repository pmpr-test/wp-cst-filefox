<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6794e750d6dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\154\x65\x5f\x72\145\x71\165\x65\163\164"; const suooagqkicoeawcy = "\x66\151\x6c\x65\137\x70\162\x6f\x76\151\x64\x65"; }
