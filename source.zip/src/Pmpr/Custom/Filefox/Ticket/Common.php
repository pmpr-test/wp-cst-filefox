<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d410ebe55a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\145\x5f\x72\x65\x71\x75\x65\163\x74"; const suooagqkicoeawcy = "\x66\151\154\x65\137\x70\x72\157\x76\151\x64\x65"; }
