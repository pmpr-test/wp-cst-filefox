<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4759a2f6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\x6c\x65\x5f\162\145\161\165\x65\x73\x74"; const suooagqkicoeawcy = "\146\x69\154\145\x5f\160\x72\x6f\166\151\x64\145"; }
