<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c5a9508             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\x65\137\x72\145\x71\x75\145\x73\164"; const suooagqkicoeawcy = "\146\x69\x6c\x65\137\160\x72\x6f\166\x69\144\x65"; }
