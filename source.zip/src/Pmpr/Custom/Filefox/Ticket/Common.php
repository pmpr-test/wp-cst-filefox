<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679151225ff18             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\154\x65\137\x72\145\x71\165\x65\x73\164"; const suooagqkicoeawcy = "\x66\151\154\145\x5f\x70\x72\157\166\151\x64\x65"; }
