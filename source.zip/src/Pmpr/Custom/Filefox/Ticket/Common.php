<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd4578210c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\145\137\162\x65\x71\x75\145\x73\164"; const suooagqkicoeawcy = "\146\x69\154\x65\x5f\x70\x72\x6f\x76\151\x64\x65"; }
