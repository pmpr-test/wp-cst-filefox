<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c4418964             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\x6c\145\x5f\162\x65\161\165\x65\x73\x74"; const suooagqkicoeawcy = "\146\x69\x6c\145\137\160\x72\157\166\151\144\145"; }
