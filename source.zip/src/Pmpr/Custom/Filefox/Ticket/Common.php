<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd834bea7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\154\145\137\x72\145\x71\165\x65\163\164"; const suooagqkicoeawcy = "\146\151\154\x65\x5f\x70\x72\x6f\x76\x69\x64\145"; }
