<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebea329a6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\145\137\x72\x65\161\165\145\163\x74"; const suooagqkicoeawcy = "\146\x69\154\x65\x5f\x70\x72\x6f\166\x69\x64\x65"; }
