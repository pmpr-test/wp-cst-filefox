<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c80714dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\x6c\x65\x5f\162\145\x71\x75\x65\x73\164"; const suooagqkicoeawcy = "\x66\151\x6c\x65\x5f\x70\x72\x6f\x76\x69\144\145"; }
