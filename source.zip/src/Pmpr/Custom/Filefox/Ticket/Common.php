<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977bf0753d5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\x65\x5f\162\x65\161\165\145\163\164"; const suooagqkicoeawcy = "\x66\151\154\x65\x5f\x70\162\x6f\x76\151\x64\x65"; }
