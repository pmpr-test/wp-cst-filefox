<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff670872f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\145\137\x72\145\x71\165\145\x73\164"; const suooagqkicoeawcy = "\146\151\x6c\x65\137\x70\x72\157\166\151\x64\145"; }
