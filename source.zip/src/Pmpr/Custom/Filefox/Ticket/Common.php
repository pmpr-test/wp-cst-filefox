<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d3dc218a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\154\145\x5f\162\145\161\x75\x65\163\164"; const suooagqkicoeawcy = "\x66\x69\154\145\x5f\x70\x72\x6f\166\151\x64\x65"; }
