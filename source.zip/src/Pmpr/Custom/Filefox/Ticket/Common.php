<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffd43d060             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\154\145\x5f\x72\x65\x71\x75\145\163\164"; const suooagqkicoeawcy = "\x66\151\x6c\145\x5f\160\x72\x6f\166\151\144\145"; }
