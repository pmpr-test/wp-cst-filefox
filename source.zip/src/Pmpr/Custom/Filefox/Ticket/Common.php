<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb83d60f3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\154\145\137\162\x65\161\x75\x65\163\164"; const suooagqkicoeawcy = "\x66\x69\x6c\145\137\160\x72\157\x76\x69\144\145"; }
