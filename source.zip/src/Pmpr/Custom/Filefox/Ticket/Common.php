<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46aadb997             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\x6c\x65\x5f\162\x65\x71\165\145\163\164"; const suooagqkicoeawcy = "\x66\151\154\x65\137\x70\162\157\166\x69\x64\145"; }
