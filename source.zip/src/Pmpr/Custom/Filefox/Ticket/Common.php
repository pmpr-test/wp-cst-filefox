<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795e80fc4619             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\154\145\137\162\145\x71\165\145\x73\x74"; const suooagqkicoeawcy = "\x66\x69\154\145\x5f\x70\162\x6f\x76\x69\x64\x65"; }
