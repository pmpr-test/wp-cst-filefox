<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0003ea178             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\145\x5f\x72\145\x71\x75\x65\x73\164"; const suooagqkicoeawcy = "\146\151\x6c\x65\x5f\x70\x72\x6f\x76\x69\x64\145"; }
