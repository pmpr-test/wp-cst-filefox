<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b688e00             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\145\x5f\162\x65\x71\165\x65\163\164"; const suooagqkicoeawcy = "\x66\x69\x6c\x65\137\160\x72\x6f\x76\151\144\x65"; }
