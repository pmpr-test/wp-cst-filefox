<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8ce889f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\154\145\137\162\145\161\x75\145\163\164"; const suooagqkicoeawcy = "\x66\x69\x6c\145\137\x70\x72\157\166\151\x64\x65"; }
