<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051750f1acb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\154\x65\x5f\162\x65\x71\165\x65\163\x74"; const suooagqkicoeawcy = "\x66\151\x6c\145\x5f\x70\162\157\x76\151\144\x65"; }
