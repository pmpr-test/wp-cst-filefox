<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4e66dd14             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\154\145\x5f\x72\145\x71\165\145\163\164"; const suooagqkicoeawcy = "\146\151\154\145\137\x70\x72\157\x76\151\144\x65"; }
