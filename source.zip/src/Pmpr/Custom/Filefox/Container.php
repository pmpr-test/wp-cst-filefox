<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             683729f49e1b2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
