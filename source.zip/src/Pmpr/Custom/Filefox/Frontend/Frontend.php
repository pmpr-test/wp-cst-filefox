<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06163927             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend; use Pmpr\Custom\Filefox\Frontend\Page\Page; class Frontend extends Common { public function mameiwsayuyquoeq() { Ajax::symcgieuakksimmu(); Page::symcgieuakksimmu(); } }
