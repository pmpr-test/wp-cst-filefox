<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793d96464dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend; use Pmpr\Custom\Filefox\Container; use Pmpr\Custom\Filefox\Frontend\Page\Download; use Pmpr\Custom\Filefox\Frontend\Page\Request\Download as RequestDownload; use Pmpr\Custom\Filefox\Frontend\Page\Request\Request; use Pmpr\Custom\Filefox\Frontend\Page\Request\Upload; class Frontend extends Container { public function mameiwsayuyquoeq() { Download::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->ligksaggegsygqwo()) { Upload::symcgieuakksimmu(); Request::symcgieuakksimmu(); RequestDownload::symcgieuakksimmu(); } if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } }
