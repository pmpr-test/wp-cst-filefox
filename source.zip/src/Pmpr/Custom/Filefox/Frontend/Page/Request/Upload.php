<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c5a9508             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; class Upload extends Common { public function __construct() { $this->slug = Constants::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x50\x72\x6f\x76\x69\x64\x65\x20\x46\x69\154\x65", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }
