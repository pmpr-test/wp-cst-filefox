<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977edcdf95d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Setting\Setting; class Upload extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qikaiaaocseouyaw)->gswweykyogmsyawy(__("\120\x72\x6f\x76\x69\x64\x65\40\106\x69\x6c\145", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::uqeikoymiywauawa)); } }
