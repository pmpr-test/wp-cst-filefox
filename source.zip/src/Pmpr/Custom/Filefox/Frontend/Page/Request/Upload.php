<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835fad7e9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Filefox\Setting; class Upload extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qikaiaaocseouyaw)->gswweykyogmsyawy(__("\120\162\x6f\x76\151\144\145\x20\x46\x69\x6c\x65", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::uqeikoymiywauawa)); } }
