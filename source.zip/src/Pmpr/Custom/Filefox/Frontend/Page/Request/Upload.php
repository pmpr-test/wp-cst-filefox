<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff670872f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Setting\Setting; class Upload extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qikaiaaocseouyaw)->gswweykyogmsyawy(__("\120\x72\157\x76\151\x64\145\x20\106\151\154\145", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::uqeikoymiywauawa)); } }
