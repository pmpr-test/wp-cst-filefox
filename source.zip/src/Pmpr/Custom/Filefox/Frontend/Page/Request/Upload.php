<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679151225ff18             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Setting\Setting; class Upload extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qikaiaaocseouyaw)->gswweykyogmsyawy(__("\x50\x72\157\x76\151\144\x65\40\x46\151\x6c\145", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::uqeikoymiywauawa)); } }
