<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebea329a6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; class Upload extends Common { public function __construct() { $this->slug = Constants::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\120\162\x6f\166\151\144\145\40\x46\151\154\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }
