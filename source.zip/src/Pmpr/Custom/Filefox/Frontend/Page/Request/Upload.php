<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051750f1acb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; class Upload extends Common { public function __construct() { $this->slug = Constants::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\120\162\x6f\166\151\x64\x65\x20\106\151\x6c\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }
