<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06163927             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Frontend\Page\Common; class Request extends Common { public function __construct() { $this->slug = Constants::qgeesceacsmeqacu; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\122\x65\x71\x75\x65\x73\164", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }
