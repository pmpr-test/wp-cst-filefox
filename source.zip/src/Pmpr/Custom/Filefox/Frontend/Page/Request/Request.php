<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff670872f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Setting\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qgeesceacsmeqacu)->gswweykyogmsyawy(__("\x52\145\161\x75\x65\163\164", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wiqyuskqsguiamau)); } }
