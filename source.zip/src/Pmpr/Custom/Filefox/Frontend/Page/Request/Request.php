<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a28575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Frontend\Page\Common; class Request extends Common { public function __construct() { $this->slug = Constants::qgeesceacsmeqacu; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\x65\x71\165\145\x73\164", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }
