<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46aadb997             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Frontend\Page\Common; class Request extends Common { public function __construct() { $this->slug = Constants::qgeesceacsmeqacu; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\x65\161\165\145\163\164", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }
