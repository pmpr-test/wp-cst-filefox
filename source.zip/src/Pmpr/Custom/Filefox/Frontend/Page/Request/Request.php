<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd834bea7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Filefox\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qgeesceacsmeqacu)->gswweykyogmsyawy(__("\122\x65\161\x75\x65\x73\x74", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wiqyuskqsguiamau)); } }
