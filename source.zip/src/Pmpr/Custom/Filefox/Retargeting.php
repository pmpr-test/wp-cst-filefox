<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6952c8c8d0788             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; use Pmpr\Common\Foundation\Interfaces\Constants; class Retargeting extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('retargeting_localize_product_fields', [$this, 'msggcuwaiyeggwwm'])->aqaqisyssqeomwom('retargeting_rest_prepared_product', [$this, 'iukyegcysigimekm'], 10, 2); } public function iukyegcysigimekm($qsqwqsymmqeoqwcu, $umkkkaqkwugkemce) { if ($umkkkaqkwugkemce) { $uycaaqiuaswwyamg = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->kckogqkiycqeumoa($umkkkaqkwugkemce, Constants::oeeqisiiqoswqqmy); if ($uycaaqiuaswwyamg) { $qsqwqsymmqeoqwcu['material_id'] = $this->caokeucsksukesyo()->kckogqkiycqeumoa()->iooowgsqoyqseyuu($uycaaqiuaswwyamg); } } return $qsqwqsymmqeoqwcu; } public function msggcuwaiyeggwwm($ikgwqyuyckaewsow) { $ikgwqyuyckaewsow['material_id'] = ['type' => 'Number', 'default' => 0]; return $ikgwqyuyckaewsow; } }
