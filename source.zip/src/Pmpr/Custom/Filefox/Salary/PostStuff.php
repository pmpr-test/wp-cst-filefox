<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687b62de7797b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Container; abstract class PostStuff extends Container { public function quqayeyqscgowgkc($post = null) : bool { if (empty($post)) { return false; } static $eucamwsokocsgiai = null; if (isset($eucamwsokocsgiai) && is_bool($eucamwsokocsgiai)) { return $eucamwsokocsgiai; } $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); $ycoeoaakqyskgykq = $ewgmommeawggyaek->qyeguewwsmosqcwc(); $eucamwsokocsgiai = $ewgmommeawggyaek->yciaosuiyeieceug($ycoeoaakqyskgykq, Constants::gewmeskawiqikkoc) || $ewgmommeawggyaek->yciaosuiyeieceug($ycoeoaakqyskgykq, Salary::icygkcucieasceuk); return $eucamwsokocsgiai; } }
