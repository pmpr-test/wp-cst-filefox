<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6a1625bd73ce4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Container; abstract class PostStuff extends Container { public function quqayeyqscgowgkc($post = null) : bool { if (empty($post)) { return false; } static $eucamwsokocsgiai = null; if (isset($eucamwsokocsgiai) && is_bool($eucamwsokocsgiai)) { return $eucamwsokocsgiai; } $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); $ycoeoaakqyskgykq = $ewgmommeawggyaek->qyeguewwsmosqcwc(); $eucamwsokocsgiai = $ewgmommeawggyaek->yciaosuiyeieceug($ycoeoaakqyskgykq, Constants::gewmeskawiqikkoc) || $ewgmommeawggyaek->yciaosuiyeieceug($ycoeoaakqyskgykq, Salary::icygkcucieasceuk); return $eucamwsokocsgiai; } }
