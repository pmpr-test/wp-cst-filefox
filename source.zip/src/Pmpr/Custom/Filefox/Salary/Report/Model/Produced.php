<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4dd360bc91             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Report\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Salary\Model\Request; class Produced extends Post { const cmiegiycgiucucgs = 'request_id'; public function register() { $this->saemoowcasogykak(IconInterface::quowqmuiikukkkay)->guiaswksukmgageq(__('Produced Post', PR__CST__FILEFOX))->muuwuqssqkaieqge(__('Produced Posts', PR__CST__FILEFOX)); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::cmiegiycgiucucgs)->gswweykyogmsyawy(__('User Request', PR__CST__FILEFOX))->wuuqgaekqeymecag(Request::class)); parent::uwmqacgewuauagai(); } public function aaamyckgicycisqq() : string { return self::cmiegiycgiucucgs; } public function ksgmsgmsckaoyimc($moqewomugocaueis) : ?object { return Request::symcgieuakksimmu()->iekyeyicoyyawomk()->akkkoiiymmamsauc($moqewomugocaueis); } }
