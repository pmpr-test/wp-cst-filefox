<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689a2bec3fa7e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Report\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Custom\Filefox\Salary\Model\Team; class Published extends Post { const mwisuqgywiccyykw = 'team_id'; public function register() { $this->saemoowcasogykak(IconInterface::quowqmuiikukkkay)->guiaswksukmgageq(__('Published Post', PR__CST__FILEFOX))->muuwuqssqkaieqge(__('Published Posts', PR__CST__FILEFOX)); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::mwisuqgywiccyykw)->gswweykyogmsyawy(__('Team', PR__CST__FILEFOX))->wuuqgaekqeymecag(Team::class)); parent::uwmqacgewuauagai(); } public function aaamyckgicycisqq() : string { return self::mwisuqgywiccyykw; } public function ksgmsgmsckaoyimc($moqewomugocaueis) : ?object { return Team::symcgieuakksimmu()->iekyeyicoyyawomk()->akkkoiiymmamsauc($moqewomugocaueis); } }
