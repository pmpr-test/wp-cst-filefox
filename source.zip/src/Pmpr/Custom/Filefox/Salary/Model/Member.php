<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4e66dd14             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Member extends Model { const mwisuqgywiccyykw = "\164\145\141\x6d\x5f\x69\x64"; public function register() { $this->ecmiqywsauuoccwo(Constants::ukwaycqmyyuekwqg)->ecmiqywsauuoccwo(Constants::ieioeisgwcgysukw)->ecmiqywsauuoccwo(Constants::awysmmukegasimmq)->ecmiqywsauuoccwo(Constants::weiosaewqequuyuq); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::yauicucwkgqyygas)->gswweykyogmsyawy(__("\x55\163\x65\162", PR__CST__FILEFOX))->acceqyqygswoecwe(11)); parent::uwmqacgewuauagai(); } }
