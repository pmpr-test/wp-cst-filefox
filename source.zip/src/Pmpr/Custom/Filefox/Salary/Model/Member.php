<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835fad7e9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Member extends Model { const mwisuqgywiccyykw = "\164\x65\x61\x6d\137\151\x64"; public function register() { $this->ecmiqywsauuoccwo(Constants::ukwaycqmyyuekwqg)->ecmiqywsauuoccwo(Constants::ieioeisgwcgysukw)->ecmiqywsauuoccwo(Constants::awysmmukegasimmq)->ecmiqywsauuoccwo(Constants::weiosaewqequuyuq); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::yauicucwkgqyygas)->gswweykyogmsyawy(__("\x55\x73\145\162", PR__CST__FILEFOX))->acceqyqygswoecwe(11)); parent::uwmqacgewuauagai(); } }
