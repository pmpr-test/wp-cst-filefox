<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6794e750d6dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Producer extends Member { public function register() { $this->saemoowcasogykak(IconInterface::mqiuasuykwwoiumy)->guiaswksukmgageq(__("\103\x6f\x6e\164\145\x6e\164\40\120\162\157\x64\x75\143\145\x72", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x43\157\x6e\164\x65\156\x74\x20\120\x72\157\x64\x75\x63\x65\162\x73", PR__CST__FILEFOX))->uaywwyimkgwyqwya([Constants::yiuwgggacagyeqmo => 20]); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::mwisuqgywiccyykw)->gswweykyogmsyawy(__("\124\145\x61\x6d", PR__CST__FILEFOX))->wuuqgaekqeymecag(Team::class)); parent::uwmqacgewuauagai(); } }
