<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99a2347d7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Producer extends Member { public function register() { $this->saemoowcasogykak(IconInterface::mqiuasuykwwoiumy)->guiaswksukmgageq(__("\103\157\156\x74\x65\156\x74\40\x50\x72\157\x64\x75\x63\x65\x72", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\103\157\156\164\x65\x6e\x74\x20\x50\162\x6f\x64\165\143\145\x72\163", PR__CST__FILEFOX))->uaywwyimkgwyqwya([Constants::yiuwgggacagyeqmo => 20]); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::mwisuqgywiccyykw)->gswweykyogmsyawy(__("\124\145\141\155", PR__CST__FILEFOX))->wuuqgaekqeymecag(Team::class)); parent::uwmqacgewuauagai(); } }
