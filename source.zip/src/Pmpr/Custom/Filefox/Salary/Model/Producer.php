<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030cc8304f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Producer extends Member { public function register() { $this->saemoowcasogykak(IconInterface::mqiuasuykwwoiumy)->guiaswksukmgageq(__("\x50\x72\157\x64\165\x63\145\x72", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\120\162\157\144\165\143\x65\162\163", PR__CST__FILEFOX))->uaywwyimkgwyqwya([Constants::yiuwgggacagyeqmo => 20]); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::mwisuqgywiccyykw)->gswweykyogmsyawy(__("\x54\x65\x61\x6d", PR__CST__FILEFOX))->wuuqgaekqeymecag(Team::class)); parent::uwmqacgewuauagai(); } }
