<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe567a38             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Producer extends Member { public function register() { $this->saemoowcasogykak(IconInterface::mqiuasuykwwoiumy)->guiaswksukmgageq(__("\103\x6f\x6e\164\x65\x6e\x74\x20\x50\162\x6f\144\165\x63\145\x72", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x43\x6f\x6e\164\145\x6e\x74\x20\x50\x72\x6f\x64\x75\x63\145\x72\163", PR__CST__FILEFOX))->uaywwyimkgwyqwya([Constants::yiuwgggacagyeqmo => 20]); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::mwisuqgywiccyykw)->gswweykyogmsyawy(__("\x54\x65\x61\x6d", PR__CST__FILEFOX))->wuuqgaekqeymecag(Team::class)); parent::uwmqacgewuauagai(); } }
