<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcdd6092ae             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Aggregate extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\101\147\147\x72\145\147\141\x74\145\40\124\162\141\x66\146\x69\143", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\101\147\x67\162\145\147\x61\x74\x65\40\x54\x72\141\x66\x66\x69\x63\x73", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(10); } }
