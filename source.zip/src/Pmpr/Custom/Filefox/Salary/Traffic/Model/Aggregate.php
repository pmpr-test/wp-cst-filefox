<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd46ab4bb3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Aggregate extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\101\147\147\162\x65\x67\x61\x74\x65\40\124\162\x61\146\x66\151\143", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x41\x67\147\162\145\x67\x61\164\145\40\x54\x72\x61\x66\x66\151\143\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(10); } }
