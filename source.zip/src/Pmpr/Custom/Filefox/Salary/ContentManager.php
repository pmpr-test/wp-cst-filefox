<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d410ebe55a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Module\Salary\AbstractSalary; class ContentManager extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = sprintf(__("\106\151\154\145\106\x6f\x78\x20\103\x75\x73\164\x6f\155\x20\50\x25\163\x29", PR__CST__FILEFOX), __("\x43\157\x6e\x74\145\x6e\x74\40\115\141\x6e\x61\147\x65\162", PR__CST__FILEFOX)); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } public function vaakeoqesyogieoe($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } }
