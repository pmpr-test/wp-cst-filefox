<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c80714dc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Module\Salary\AbstractSalary; class ContentManager extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = sprintf(__("\106\151\154\145\x46\157\x78\40\x43\165\163\164\x6f\155\40\x28\x25\x73\x29", PR__CST__FILEFOX), __("\x43\157\x6e\164\x65\156\164\40\x4d\x61\156\141\x67\145\x72", PR__CST__FILEFOX)); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } public function vaakeoqesyogieoe($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } }
