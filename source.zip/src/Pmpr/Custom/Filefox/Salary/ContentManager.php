<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da2f5c3f9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Module\Salary\AbstractSalary; class ContentManager extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = sprintf(__("\x46\x69\x6c\x65\x46\157\x78\40\x43\x75\x73\164\x6f\x6d\40\50\x25\x73\51", PR__CST__FILEFOX), __("\x43\x6f\x6e\x74\145\156\x74\x20\x4d\x61\x6e\141\x67\145\162", PR__CST__FILEFOX)); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } public function vaakeoqesyogieoe($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } }
