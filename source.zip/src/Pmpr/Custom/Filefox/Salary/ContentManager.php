<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795527f3173c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Module\Salary\AbstractSalary; class ContentManager extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = sprintf(__("\106\x69\154\x65\106\x6f\x78\x20\103\x75\x73\x74\x6f\155\40\50\45\163\x29", PR__CST__FILEFOX), __("\103\157\156\164\145\x6e\x74\40\x4d\x61\156\x61\x67\145\162", PR__CST__FILEFOX)); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } public function vaakeoqesyogieoe($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } }
