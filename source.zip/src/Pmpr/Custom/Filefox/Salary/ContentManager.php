<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795e80fc4619             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Module\Salary\AbstractSalary; class ContentManager extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = sprintf(__("\x46\151\x6c\x65\106\x6f\170\x20\x43\165\163\x74\157\155\40\x28\45\x73\x29", PR__CST__FILEFOX), __("\103\x6f\x6e\164\x65\156\164\x20\115\141\x6e\141\147\145\x72", PR__CST__FILEFOX)); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } public function vaakeoqesyogieoe($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } }
