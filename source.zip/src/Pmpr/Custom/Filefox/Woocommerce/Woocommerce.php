<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8686507c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Single::symcgieuakksimmu(); } }
