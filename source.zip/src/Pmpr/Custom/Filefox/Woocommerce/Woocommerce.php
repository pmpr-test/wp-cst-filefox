<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a28575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Single::symcgieuakksimmu(); } }
