<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0003ea178             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Single::symcgieuakksimmu(); } }
