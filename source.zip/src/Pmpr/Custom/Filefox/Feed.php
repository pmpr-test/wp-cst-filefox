<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac2636008bb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Feed extends Container { }
