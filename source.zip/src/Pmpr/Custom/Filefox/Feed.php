<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac85971d7d8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Feed extends Container { }
