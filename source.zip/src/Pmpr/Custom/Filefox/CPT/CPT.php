<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d719a78e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Custom\Filefox\Container; class CPT extends Container { public function mameiwsayuyquoeq() { News::symcgieuakksimmu(); Product::symcgieuakksimmu(); } }
