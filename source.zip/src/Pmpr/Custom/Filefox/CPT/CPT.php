<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecadf46170             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Common\Foundation\FormGenerator\Backend\CPTMetaBox; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class CPT extends CPTMetaBox { const qeumwkkmoamqwumc = 'post_summary'; public function mameiwsayuyquoeq() { Post::symcgieuakksimmu(); News::symcgieuakksimmu(); Article::symcgieuakksimmu(); Product::symcgieuakksimmu(); $this->mgieiwsmcswmmiim(Constants::mswoacegomcucaik)->mgieiwsmcswmmiim(Constants::sususqikkuaoqeco)->mgieiwsmcswmmiim(Constants::oguseymmyyoyaako); } public function qyecwywaoyamkmci() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->sikqggwmmykuiymy($uuyucgkyusckoaeq->scyscgskcwukckyy('custom_summary')->saemoowcasogykak(IconInterface::egyukkakakommeig)->gswweykyogmsyawy(__('Custom Summary', PR__CST__FILEFOX))->qqqycgoaysysgiqm()->mkksewyosgeumwsa($uuyucgkyusckoaeq->uouyygwcgsmygaee(self::qeumwkkmoamqwumc)->gswweykyogmsyawy(__('Short Summery', PR__CST__FILEFOX))->qsecygiycssgacqs(2))); } }
