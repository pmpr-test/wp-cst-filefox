<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b4a683af35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Common\Foundation\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class News extends CPT { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum, Constants::aymgsswocykmwwku])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->muuwuqssqkaieqge(__('News', PR__CST__FILEFOX))->guiaswksukmgageq(__('The News', PR__CST__FILEFOX))->acqyqaaeeogkosoq(Constants::qgciomgukmcwscqw)->yioesawwewqaigow('dashicons-admin-site-alt'); } }
