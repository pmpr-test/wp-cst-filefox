<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689a2bec3fa7e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; use Pmpr\Common\Foundation\Interfaces\Constants; class Yoast extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('admin_bar_menu', [$this, 'waecyegsuwkoyqao'], 999); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('views_edit-post', [$this, 'aqoeiycemiksckcu'], 20); } public function waecyegsuwkoyqao($wpAdminBar) { $wpAdminBar->remove_node('wpseo-menu'); } public function aqoeiycemiksckcu($umwgoasiowmqcumw) { foreach ($umwgoasiowmqcumw as $uusmaiomayssaecw => $qqomumygoacsmsie) { if (str_contains($uusmaiomayssaecw, 'yoast')) { unset($umwgoasiowmqcumw[$uusmaiomayssaecw]); } } return $umwgoasiowmqcumw; } }
