<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795e80fc4619             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Aggregate extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\101\147\x67\x72\145\147\141\x74\145\x20\124\162\x61\x66\x66\x69\x63", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x41\x67\147\x72\x65\147\x61\164\145\40\124\162\x61\146\146\151\143\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(10); } }
