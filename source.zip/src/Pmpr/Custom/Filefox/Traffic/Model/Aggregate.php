<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da2f5c3f9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Aggregate extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\101\x67\147\x72\x65\147\141\x74\145\x20\124\162\141\146\x66\x69\x63", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\101\147\147\162\x65\x67\141\164\145\x20\x54\162\x61\x66\146\151\x63\x73", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(10); } }
