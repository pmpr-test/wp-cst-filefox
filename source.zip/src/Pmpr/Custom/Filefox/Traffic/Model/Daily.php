<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977cbabe45f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Daily extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\x44\x61\151\x6c\x79\x20\124\x72\141\146\x66\x69\143", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\104\141\151\154\x79\40\124\x72\x61\x66\x66\151\143\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(8); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->qwwuoqeeiyuoyogs(Constants::kumuoysauoagaiiy)->gswweykyogmsyawy(__("\x44\x61\164\x65", PR__CST__FILEFOX))->qcqeqimisiisswky()); } }
