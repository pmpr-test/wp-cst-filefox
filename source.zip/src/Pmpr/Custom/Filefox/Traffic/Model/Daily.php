<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977bf0753d5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Daily extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\x44\141\151\154\171\40\x54\162\141\146\x66\151\x63", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x44\141\x69\154\x79\x20\x54\x72\141\x66\146\x69\143\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(8); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->qwwuoqeeiyuoyogs(Constants::kumuoysauoagaiiy)->gswweykyogmsyawy(__("\104\141\164\x65", PR__CST__FILEFOX))->qcqeqimisiisswky()); } }
