<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795e80fc4619             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Daily extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\x44\141\151\x6c\171\40\124\162\141\146\x66\151\143", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x44\x61\x69\154\171\x20\x54\162\141\146\x66\x69\143\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(8); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->qwwuoqeeiyuoyogs(Constants::kumuoysauoagaiiy)->gswweykyogmsyawy(__("\x44\141\x74\x65", PR__CST__FILEFOX))->qcqeqimisiisswky()); } }
