<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977edcdf95d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Daily extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\104\x61\151\x6c\171\x20\124\x72\x61\146\x66\x69\x63", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x44\141\151\x6c\171\x20\124\162\x61\x66\x66\x69\143\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(8); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->qwwuoqeeiyuoyogs(Constants::kumuoysauoagaiiy)->gswweykyogmsyawy(__("\104\141\x74\145", PR__CST__FILEFOX))->qcqeqimisiisswky()); } }
