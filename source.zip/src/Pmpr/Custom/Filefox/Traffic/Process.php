<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffd43d060             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\146\x5f\164\162\141\x66\146\151\143\x5f\152\157\x62\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\x65\x74\143\x68\137\x70\141\147\x65\x73\x5f\x64\x61\164\141"; public function ikcgmcycisiccyuc() { $this->group = "\x66\x66\x5f\x74\162\141\146\146\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\x69\x67\150\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
