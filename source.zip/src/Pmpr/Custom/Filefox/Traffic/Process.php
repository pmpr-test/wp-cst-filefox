<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da2f5c3f9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\146\x5f\164\x72\x61\146\x66\x69\x63\137\x6a\x6f\x62\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\x74\x63\x68\137\160\141\x67\x65\x73\x5f\144\141\164\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\x5f\164\162\x61\x66\146\151\143"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\151\147\x68\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
