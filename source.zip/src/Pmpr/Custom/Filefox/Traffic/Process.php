<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977cbabe45f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\x66\137\164\x72\141\146\x66\x69\143\137\x6a\157\142\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\145\164\x63\x68\137\x70\x61\147\x65\x73\x5f\x64\141\164\141"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\x5f\x74\x72\x61\146\x66\x69\143"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\x6e\x69\147\150\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
