<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb83d60f3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\146\137\x74\x72\141\x66\146\151\x63\137\152\157\142\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\145\164\x63\x68\x5f\x70\141\147\x65\x73\x5f\144\141\164\x61"; public function ikcgmcycisiccyuc() { $this->group = "\x66\146\x5f\x74\162\141\146\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\x69\x67\150\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
