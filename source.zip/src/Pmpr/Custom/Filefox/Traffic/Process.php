<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793d96464dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\x66\x5f\164\x72\141\x66\146\151\x63\x5f\152\157\142\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\x74\x63\x68\137\x70\x61\147\x65\163\x5f\144\x61\x74\x61"; public function ikcgmcycisiccyuc() { $this->group = "\x66\x66\137\164\162\141\146\146\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\x6e\x69\x67\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
