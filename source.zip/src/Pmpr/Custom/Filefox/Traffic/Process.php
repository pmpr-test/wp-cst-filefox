<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977edcdf95d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\146\x5f\164\162\141\146\146\x69\143\137\152\x6f\x62\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\145\164\143\150\137\160\x61\147\x65\x73\137\x64\141\164\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\x66\x5f\x74\x72\x61\146\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\x69\147\150\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
