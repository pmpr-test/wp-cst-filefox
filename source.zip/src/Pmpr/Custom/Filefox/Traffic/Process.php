<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523954224             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\x66\137\x74\x72\x61\x66\146\x69\143\x5f\x6a\157\x62\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\145\164\x63\150\x5f\x70\x61\x67\145\163\137\x64\x61\x74\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\x5f\164\x72\x61\x66\146\x69\143"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\x6e\151\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
