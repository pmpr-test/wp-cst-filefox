<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff670872f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\146\137\164\162\141\x66\146\151\x63\x5f\x6a\x6f\142\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\145\164\x63\x68\137\160\x61\147\145\x73\x5f\x64\x61\x74\141"; public function ikcgmcycisiccyuc() { $this->group = "\x66\146\x5f\164\162\x61\x66\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\x69\147\x68\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
