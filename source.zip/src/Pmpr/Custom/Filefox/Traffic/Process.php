<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977bf0753d5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\x66\x5f\164\162\x61\x66\146\x69\x63\137\152\157\x62\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\164\x63\150\137\160\x61\x67\x65\163\137\x64\141\x74\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\x5f\x74\x72\141\146\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
