<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb2c6f1b5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\x66\x5f\164\x72\141\x66\146\151\x63\137\x6a\x6f\142\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\x65\x74\143\150\137\x70\141\x67\145\x73\137\x64\141\164\141"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\x5f\164\x72\x61\146\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
