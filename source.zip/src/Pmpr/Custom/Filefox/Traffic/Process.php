<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679151225ff18             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\146\137\164\x72\x61\146\x66\151\x63\x5f\152\x6f\x62\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\x74\143\x68\137\160\141\x67\145\163\137\x64\x61\164\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\x66\x5f\x74\x72\141\146\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
