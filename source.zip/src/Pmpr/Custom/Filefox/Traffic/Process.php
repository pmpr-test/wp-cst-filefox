<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6794e750d6dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\x66\137\164\x72\141\146\x66\151\x63\x5f\x6a\x6f\x62\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\x74\143\150\x5f\160\141\147\x65\163\x5f\144\x61\164\141"; public function ikcgmcycisiccyuc() { $this->group = "\x66\146\x5f\164\x72\141\x66\x66\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\156\151\x67\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
