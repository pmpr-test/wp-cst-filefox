<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795527f3173c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\x66\x5f\x74\x72\141\146\146\151\x63\x5f\152\x6f\x62\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\145\164\x63\x68\137\x70\141\x67\x65\x73\137\144\x61\x74\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\x5f\x74\162\x61\146\146\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\151\147\150\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
