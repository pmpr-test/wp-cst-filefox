<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795e80fc4619             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\146\x5f\x74\162\141\x66\146\x69\x63\137\152\157\142\x5f"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\145\x74\143\x68\x5f\160\141\x67\145\x73\137\x64\x61\164\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\x66\x5f\x74\162\x61\x66\146\151\143"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\x6e\x69\x67\x68\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }
