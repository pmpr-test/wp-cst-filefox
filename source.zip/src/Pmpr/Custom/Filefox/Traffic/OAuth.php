<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3ff82412c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Google_Service_Webmasters; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ThirdParty\Google\OAuth as GoogleOAuth; use Pmpr\Common\Foundation\ThirdParty\Google\SettingSegment; class OAuth extends GoogleOAuth { public function qiccuiwooiquycsg() { $this->igiywquyccyiaucw(Constants::eoyiggawwagyugua, Google_Service_Webmasters::ymyoewmqowkygoko); } public function ykuqkkqmsymwaqak() : SettingSegment { return Setting::symcgieuakksimmu(); } }
