<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc702f57cf5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { }
