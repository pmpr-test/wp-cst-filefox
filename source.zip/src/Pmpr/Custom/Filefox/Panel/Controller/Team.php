<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb2c6f1b5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class Team extends Controller { }
