<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6794e750d6dc7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class Team extends Controller { }
