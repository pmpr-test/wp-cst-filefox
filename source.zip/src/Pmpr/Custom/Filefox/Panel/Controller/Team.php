<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d3dc218a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class Team extends Controller { }
