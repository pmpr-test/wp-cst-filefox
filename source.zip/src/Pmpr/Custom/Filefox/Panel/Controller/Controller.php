<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff670872f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; use Pmpr\Custom\Filefox\Salary\Salary; use Pmpr\Module\Panel\REST\AbstractREST; abstract class Controller extends AbstractREST { public function __construct() { $this->abstract = true; parent::__construct(); $this->namespace .= "\x2f\143\x6f\156\164\145\156\x74"; } public function emwagqamysmyeigc($mkucggyaiaukqoce) : bool { return $this->caokeucsksukesyo()->issssuygyewuaswa()->askmkgcmgekiqwsg(Salary::icygkcucieasceuk, $mkucggyaiaukqoce, true); } public function mgawqagyqukmasom($mkucggyaiaukqoce) : bool { return $this->caokeucsksukesyo()->issssuygyewuaswa()->askmkgcmgekiqwsg(Salary::emceseoyeswkikuu, $mkucggyaiaukqoce, true); } public function iugaygkgyqmwqmus() : bool { } }
