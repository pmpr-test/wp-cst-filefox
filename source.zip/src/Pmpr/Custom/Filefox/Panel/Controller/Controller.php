<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523954224             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; use Pmpr\Custom\Filefox\Salary\Salary; use Pmpr\Module\Panel\REST\AbstractREST; abstract class Controller extends AbstractREST { public function __construct() { $this->abstract = true; parent::__construct(); $this->namespace .= "\x2f\x63\x6f\x6e\x74\145\x6e\x74"; } public function emwagqamysmyeigc($mkucggyaiaukqoce) : bool { return $this->caokeucsksukesyo()->issssuygyewuaswa()->askmkgcmgekiqwsg(Salary::icygkcucieasceuk, $mkucggyaiaukqoce, true); } public function mgawqagyqukmasom($mkucggyaiaukqoce) : bool { return $this->caokeucsksukesyo()->issssuygyewuaswa()->askmkgcmgekiqwsg(Salary::emceseoyeswkikuu, $mkucggyaiaukqoce, true); } public function iugaygkgyqmwqmus() : bool { } }
