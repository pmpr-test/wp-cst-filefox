<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             683729f49e1b2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = 'content-management'; parent::__construct(); } }
