<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd46ab4bb3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = "\143\157\156\x74\x65\x6e\164\x2d\155\x61\156\x61\x67\145\155\145\x6e\x74"; parent::__construct(); } }
