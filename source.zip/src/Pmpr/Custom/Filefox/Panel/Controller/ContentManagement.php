<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcdd6092ae             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = "\x63\x6f\156\x74\145\x6e\x74\x2d\155\141\x6e\141\147\x65\155\x65\156\x74"; parent::__construct(); } }
