<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8ce889f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = "\143\x6f\156\164\x65\x6e\x74\55\x6d\x61\156\x61\x67\x65\x6d\x65\156\x74"; parent::__construct(); } }
