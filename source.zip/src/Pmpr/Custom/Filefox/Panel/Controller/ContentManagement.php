<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd4578210c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = "\143\x6f\x6e\x74\145\x6e\x74\x2d\x6d\x61\156\x61\x67\145\x6d\145\156\x74"; parent::__construct(); } }
