<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051750f1acb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\146\157\x72\x65\137\x65\x6e\161\165\145\x75\145\x5f\142\x61\x63\x6b\x65\x6e\144\137\141\163\x73\145\x74\x73", [$this, "\145\156\161\165\x65\x75\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\142\x61\143\153\145\x6e\144", $eygsasmqycagyayw->get("\x62\141\143\153\x65\x6e\144\56\152\x73"))->simswskycwagoeqy()); } }
