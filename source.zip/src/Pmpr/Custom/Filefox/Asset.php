<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8686507c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\146\x6f\x72\x65\137\145\156\161\x75\145\165\145\x5f\142\141\143\153\145\156\144\x5f\141\x73\163\145\x74\x73", [$this, "\145\156\x71\165\x65\x75\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\142\x61\x63\153\x65\156\144", $eygsasmqycagyayw->get("\x62\141\143\153\x65\156\144\x2e\152\163"))->simswskycwagoeqy()); } }
