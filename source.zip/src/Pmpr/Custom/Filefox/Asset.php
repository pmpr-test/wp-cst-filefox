<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0003ea178             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\146\x6f\162\145\x5f\145\x6e\x71\x75\145\x75\145\137\x62\x61\143\153\x65\156\144\137\x61\x73\x73\x65\x74\163", [$this, "\x65\x6e\161\x75\x65\165\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\141\x63\153\145\156\144", $eygsasmqycagyayw->get("\x62\x61\x63\153\x65\x6e\144\x2e\x6a\163"))->simswskycwagoeqy()); } }
