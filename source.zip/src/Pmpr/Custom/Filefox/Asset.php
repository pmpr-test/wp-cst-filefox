<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebea329a6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\x66\157\162\x65\137\145\x6e\161\x75\145\165\145\137\x62\141\143\153\x65\156\144\137\x61\x73\x73\x65\164\163", [$this, "\x65\x6e\x71\165\145\x75\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\142\141\143\153\x65\156\144", $eygsasmqycagyayw->get("\142\141\x63\153\145\156\144\x2e\152\x73"))->simswskycwagoeqy()); } }
