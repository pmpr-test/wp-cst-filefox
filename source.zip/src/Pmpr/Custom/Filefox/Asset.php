<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c1a363             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\146\157\162\145\x5f\x65\156\x71\x75\x65\165\145\x5f\142\x61\x63\x6b\145\x6e\x64\137\141\x73\x73\145\164\163", [$this, "\x65\x6e\x71\x75\145\165\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\x61\x63\153\145\x6e\144", $eygsasmqycagyayw->get("\142\x61\143\153\x65\156\144\x2e\152\x73"))->simswskycwagoeqy()); } }
