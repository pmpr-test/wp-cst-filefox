<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46aadb997             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\162\145\137\145\156\x71\x75\x65\165\x65\137\x62\141\x63\153\145\156\x64\x5f\141\163\x73\x65\x74\163", [$this, "\145\156\x71\165\145\165\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\141\x63\153\145\x6e\144", $eygsasmqycagyayw->get("\142\141\x63\153\x65\x6e\x64\56\152\x73"))->simswskycwagoeqy()); } }
