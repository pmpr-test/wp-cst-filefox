<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc06163927             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\146\157\162\x65\137\x65\156\x71\165\145\165\145\137\x62\x61\143\153\x65\x6e\x64\x5f\141\163\163\x65\x74\x73", [$this, "\x65\156\161\x75\145\165\145"]); } public function enqueue() { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->qeqgammgesiwiysc($meakksicouekcgoe->owygwqwawqoiusis($this, "\142\x61\x63\153\x65\x6e\144", "\x62\141\143\x6b\145\x6e\x64\56\x6a\163")->simswskycwagoeqy()); } }
