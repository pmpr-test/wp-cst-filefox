<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a28575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage\Model; use Pmpr\Common\Foundation\ORM\DB\Model as BaseClass; abstract class Common extends BaseClass { public function ckgmycmaukqgkosk() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->okgmqaeuaeymaocm($wksoawcgagcgoask)->wiskakymeaywyeuw($wksoawcgagcgoask); parent::ckgmycmaukqgkosk(); } }
